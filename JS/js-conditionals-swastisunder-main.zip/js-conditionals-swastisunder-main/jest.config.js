export default {
  testEnvironment: 'node',
  transform: {},
  testMatch: ['**/tests/**/*.spec.js'],
  verbose: true,
};
